import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, orderBy, limit, addDoc, serverTimestamp, doc, updateDoc, deleteDoc, where, getDocs, writeBatch, setDoc, getDoc } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { useAuth } from '../AuthContext';
import { Tile, Transaction, UserProfile, Vendor, VendorTransaction } from '../types';
import { formatCurrency, cn, safeFormatDate } from '../lib/utils';
import { 
  LayoutDashboard, 
  Package, 
  History, 
  Users, 
  LogOut, 
  Plus, 
  Search, 
  AlertTriangle, 
  TrendingUp, 
  DollarSign, 
  ShoppingCart,
  ShoppingBag,
  Truck,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  Menu,
  X,
  ChevronRight,
  Eye
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Dashboard: React.FC = () => {
  const { user, profile, loading: authLoading } = useAuth();
  const [isLinking, setIsLinking] = useState(false);
  const [hasAttemptedLink, setHasAttemptedLink] = useState(false);
  const [linkError, setLinkError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'inventory' | 'transactions' | 'purchases' | 'vendors' | 'users'>('dashboard');
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [vendorTransactions, setVendorTransactions] = useState<VendorTransaction[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Modals
  const [showAddTile, setShowAddTile] = useState(false);
  const [showAddUser, setShowAddUser] = useState(false);
  const [showAddVendor, setShowAddVendor] = useState(false);
  const [showVendorTransactionModal, setShowVendorTransactionModal] = useState<Vendor | null>(null);
  const [selectedVendor, setSelectedVendor] = useState<Vendor | null>(null);
  const [showSaleModal, setShowSaleModal] = useState<Tile | null>(null);
  const [showRestockModal, setShowRestockModal] = useState<Tile | null>(null);
  const [showTileSelector, setShowTileSelector] = useState<{ mode: 'sale' | 'restock' } | null>(null);
  const [editingTile, setEditingTile] = useState<Tile | null>(null);
  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  useEffect(() => {
    if (!user || profile || isLinking || hasAttemptedLink) return;

    const attemptLinking = async () => {
      setIsLinking(true);
      setHasAttemptedLink(true);
      setLinkError(null);
      try {
        const userEmail = user.email?.toLowerCase().trim();
        if (!userEmail) throw new Error("No email found in Google account.");

        // Check if the user already has a linked profile
        const userDocRef = doc(db, 'users', user.uid);
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          console.log("Profile already linked.");
          return;
        }

        // Check for pre-approved email record (using email as ID)
        const approvedDocRef = doc(db, 'users', userEmail);
        let approvedDoc = null;
        let approvedData = null;

        try {
          approvedDoc = await getDoc(approvedDocRef);
          if (approvedDoc.exists()) {
            approvedData = approvedDoc.data();
          }
        } catch (e) {
          console.log("Direct ID lookup failed (likely permission or non-existent):", e);
        }

        if (!approvedData) {
          // Fallback: Search by email field (in case ID approach fails or is restricted)
          console.log("Fallback search for:", userEmail);
          try {
            const q = query(collection(db, 'users'), where('email', '==', userEmail), where('status', '==', 'approved'), limit(1));
            const querySnapshot = await getDocs(q);
            if (!querySnapshot.empty) {
              approvedDoc = querySnapshot.docs[0];
              approvedData = approvedDoc.data();
            }
          } catch (e) {
            console.error("Fallback search failed:", e);
          }
        }

        if (approvedData) {
          console.log("Linking pre-approved account:", approvedData);
          
          try {
            // Link UID to this record by creating a new document with the real UID
            const newProfile = {
              ...approvedData,
              uid: user.uid,
              updatedAt: serverTimestamp(),
            };
            
            // Ensure createdAt exists and is a valid format if possible
            if (!newProfile.createdAt) {
              newProfile.createdAt = serverTimestamp();
            }

            await setDoc(doc(db, 'users', user.uid), newProfile);
            
            // Delete the placeholder document
            if (approvedDoc && approvedDoc.id) {
              await deleteDoc(doc(db, 'users', approvedDoc.id));
            }
            console.log("Linking successful!");
          } catch (e) {
            console.error("Linking write failed:", e);
            setLinkError("Failed to link your account. Please contact support.");
          }
        } else {
          // No pre-approved record found. Check if super admin
          const SUPER_ADMIN_EMAILS = ['newsampeterson.33@gmail.com', 'owiat.jefferson.official@gmail.com'];
          console.log("No pre-approved record found for:", userEmail);
          
          if (SUPER_ADMIN_EMAILS.includes(userEmail)) {
            await setDoc(doc(db, 'users', user.uid), {
              uid: user.uid,
              name: user.displayName || 'Super Admin',
              email: userEmail,
              role: 'admin',
              status: 'approved',
              createdAt: serverTimestamp()
            });
            console.log("Super Admin auto-approved");
          } else {
            setLinkError("Your email has not been pre-approved. Please contact your administrator.");
          }
        }
      } catch (err: any) {
        console.error("Linking error:", err);
        setLinkError(err.message);
      } finally {
        setIsLinking(false);
      }
    };

    attemptLinking();
  }, [user, profile, isLinking]);

  useEffect(() => {
    if (!profile || !user) return;

    // Self-fix for Super Admin: If logged in with admin email but profile is not approved/admin
    if (isSuperAdmin() && (profile.status !== 'approved' || profile.role !== 'admin')) {
      updateDoc(doc(db, 'users', user.uid), {
        status: 'approved',
        role: 'admin'
      }).catch(err => console.error("Auto-approval failed:", err));
    }

    if (profile.status !== 'approved') return;

    const unsubTiles = onSnapshot(collection(db, 'tiles'), (snapshot) => {
      setTiles(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Tile)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'tiles'));

    const unsubTransactions = onSnapshot(query(collection(db, 'transactions'), orderBy('timestamp', 'desc'), limit(50)), (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'transactions'));

    const unsubVendors = onSnapshot(collection(db, 'vendors'), (snapshot) => {
      setVendors(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Vendor)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'vendors'));

    const unsubVendorTransactions = onSnapshot(query(collection(db, 'vendorTransactions'), orderBy('date', 'desc')), (snapshot) => {
      setVendorTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as VendorTransaction)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'vendorTransactions'));

    if (profile.role === 'admin') {
      const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
        setAllUsers(snapshot.docs.map(doc => ({ ...doc.data() } as UserProfile)));
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'users'));
      return () => { unsubTiles(); unsubTransactions(); unsubVendors(); unsubVendorTransactions(); unsubUsers(); };
    }

    return () => { unsubTiles(); unsubTransactions(); unsubVendors(); unsubVendorTransactions(); };
  }, [profile]);

  const isSuperAdmin = () => {
    return user?.email === 'newsampeterson.33@gmail.com' || user?.email === 'owiat.jefferson.official@gmail.com';
  };

  if (authLoading || isLinking || (!profile && !hasAttemptedLink)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 font-medium animate-pulse">
            {isLinking ? 'Setting up your profile...' : 'Loading TileStock Pro...'}
          </p>
        </div>
      </div>
    );
  }

  if (!profile && hasAttemptedLink) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white rounded-3xl shadow-xl shadow-slate-200/50 p-8 text-center border border-slate-100"
        >
          <div className="w-20 h-20 bg-rose-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <XCircle className="w-10 h-10 text-rose-500" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h2>
          <div className="space-y-4 mb-8">
            <p className="text-slate-600 leading-relaxed">
              {linkError || "Your email has not been pre-approved. Please contact your administrator."}
            </p>
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Attempted Email</p>
              <p className="text-slate-700 font-mono text-sm break-all">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={() => auth.signOut()}
            className="w-full flex items-center justify-center gap-2 px-6 py-3.5 bg-slate-900 text-white rounded-xl font-semibold hover:bg-slate-800 transition-all active:scale-[0.98]"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
        </motion.div>
      </div>
    );
  }

  if (profile.status === 'pending' && !isSuperAdmin()) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center border border-slate-100">
          <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertTriangle size={40} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Account Pending Approval</h2>
          <p className="text-slate-600 mb-8">
            Your account has been created successfully. Please wait for an administrator to approve your access to the system.
          </p>
          <button 
            onClick={() => auth.signOut()}
            className="w-full py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
          >
            <LogOut size={20} /> Sign Out
          </button>
        </div>
      </div>
    );
  }

  const filteredTiles = tiles.filter(tile => 
    tile.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    tile.type.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const lowStockTiles = tiles.filter(t => t.quantity <= (t.lowStockThreshold || 10));
  const totalValue = tiles.reduce((acc, t) => acc + (t.quantity * t.costPrice), 0);
  const recentSales = transactions.slice(0, 5);

  const NavItem = ({ id, icon: Icon, label, roles, mobile }: { id: any, icon: any, label: string, roles?: string[], mobile?: boolean }) => {
    if (roles && !roles.includes(profile.role)) return null;
    const active = activeTab === id;
    
    if (mobile) {
      return (
        <button
          onClick={() => setActiveTab(id)}
          className={cn(
            "flex flex-col items-center justify-center gap-1 flex-1 py-2 transition-all",
            active ? "text-indigo-600" : "text-slate-400"
          )}
        >
          <Icon size={20} className={cn(active ? "text-indigo-600" : "text-slate-400")} />
          <span className="text-[10px] font-bold uppercase tracking-wider">{label.split(' ')[0]}</span>
          {id === 'inventory' && lowStockTiles.length > 0 && (
            <div className="absolute top-2 ml-6 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
          )}
        </button>
      );
    }

    return (
      <button
        onClick={() => { setActiveTab(id); setIsMobileMenuOpen(false); }}
        className={cn(
          "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
          active 
            ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
            : "text-slate-500 hover:bg-slate-100 hover:text-slate-900"
        )}
      >
        <Icon size={20} className={cn(active ? "text-white" : "text-slate-400 group-hover:text-slate-900")} />
        <span className="font-semibold">{label}</span>
        {id === 'inventory' && lowStockTiles.length > 0 && (
          <span className={cn(
            "ml-auto px-2 py-0.5 rounded-full text-[10px] font-bold",
            active ? "bg-white text-indigo-600" : "bg-red-100 text-red-600"
          )}>
            {lowStockTiles.length}
          </span>
        )}
      </button>
    );
  };

  const handleDeleteTile = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this tile? This action cannot be undone.")) return;
    try {
      await deleteDoc(doc(db, 'tiles', id));
      setNotification({ message: 'Tile deleted successfully', type: 'success' });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'tiles');
    }
  };

  const handleDeleteVendor = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this vendor? All their transaction history will remain but the vendor profile will be gone.")) return;
    try {
      await deleteDoc(doc(db, 'vendors', id));
      setNotification({ message: 'Vendor deleted successfully', type: 'success' });
      if (selectedVendor?.id === id) setSelectedVendor(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'vendors');
    }
  };

  const handleApproveUser = async (uid: string) => {
    try {
      await updateDoc(doc(db, 'users', uid), { status: 'approved' });
      setNotification({ message: 'Staff approved successfully', type: 'success' });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'users');
    }
  };

  const handleDeleteUser = async (uid: string) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;
    try {
      await deleteDoc(doc(db, 'users', uid));
      setNotification({ message: 'User deleted successfully', type: 'success' });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'users');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans">
      {/* Sidebar - Desktop */}
      <aside className={cn(
        "hidden md:flex flex-col bg-white border-r border-slate-200 transition-all duration-300 ease-in-out",
        isSidebarOpen ? "w-72" : "w-20"
      )}>
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-indigo-100">
            <Package className="text-white" size={24} />
          </div>
          {isSidebarOpen && <span className="text-xl font-bold text-slate-900 truncate">TileStock Pro</span>}
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <NavItem id="dashboard" icon={LayoutDashboard} label="Dashboard" />
          <NavItem id="inventory" icon={Package} label="Inventory" />
          <NavItem id="transactions" icon={History} label="Sales History" />
          <NavItem id="purchases" icon={ShoppingBag} label="Purchases" />
          <NavItem id="vendors" icon={Truck} label="Vendors" />
          <NavItem id="users" icon={Users} label="Staff Management" roles={['admin']} />
        </nav>

        <div className="p-4 border-t border-slate-100">
          <div className={cn("flex items-center gap-3 p-3 rounded-xl bg-slate-50", !isSidebarOpen && "justify-center")}>
            <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold flex-shrink-0">
              {profile.name.charAt(0)}
            </div>
            {isSidebarOpen && (
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900 truncate">{profile.name}</p>
                <p className="text-xs text-slate-500 capitalize">{profile.role}</p>
              </div>
            )}
            {isSidebarOpen && (
              <button onClick={() => auth.signOut()} className="text-slate-400 hover:text-red-500 transition-colors">
                <LogOut size={18} />
              </button>
            )}
          </div>
          {!isSidebarOpen && (
            <button onClick={() => auth.signOut()} className="w-full mt-2 flex justify-center p-2 text-slate-400 hover:text-red-500">
              <LogOut size={18} />
            </button>
          )}
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white border-b border-slate-200 z-50 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-md shadow-indigo-100">
            <Package className="text-white" size={18} />
          </div>
          <span className="font-bold text-slate-900">TileStock Pro</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs">
            {profile.name.charAt(0)}
          </div>
          <button onClick={() => auth.signOut()} className="p-2 text-slate-400 hover:text-red-500">
            <LogOut size={20} />
          </button>
        </div>
      </div>

      {/* Mobile Bottom Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-50 px-2 flex items-center justify-around pb-safe">
        <NavItem id="dashboard" icon={LayoutDashboard} label="Home" mobile />
        <NavItem id="inventory" icon={Package} label="Stock" mobile />
        <NavItem id="transactions" icon={History} label="Sales" mobile />
        <NavItem id="purchases" icon={ShoppingBag} label="Purchases" mobile />
        <NavItem id="vendors" icon={Truck} label="Vendors" mobile />
        <NavItem id="users" icon={Users} label="Staff" roles={['admin']} mobile />
      </div>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-10 mt-14 md:mt-0 mb-20 md:mb-0 overflow-y-auto">
        <header className="mb-6 md:mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-900 capitalize">{activeTab}</h1>
            <p className="text-sm md:text-base text-slate-500">Welcome back, {profile.name}</p>
          </div>
          <div className="flex items-center gap-3">
            {activeTab === 'inventory' && profile.role === 'admin' && (
              <button 
                onClick={() => setShowAddTile(true)}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
              >
                <Plus size={20} /> <span className="md:inline">Add Tile</span>
              </button>
            )}
            {activeTab === 'purchases' && (
              <div className="flex items-center gap-2 w-full md:w-auto">
                <button 
                  onClick={() => setShowTileSelector({ mode: 'sale' })}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 text-white font-bold rounded-xl shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all"
                >
                  <ShoppingCart size={20} /> <span className="md:inline">New Sale</span>
                </button>
                <button 
                  onClick={() => setShowTileSelector({ mode: 'restock' })}
                  className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-blue-600 text-white font-bold rounded-xl shadow-lg shadow-blue-100 hover:bg-blue-700 transition-all"
                >
                  <Plus size={20} /> <span className="md:inline">New Stock</span>
                </button>
              </div>
            )}
            {activeTab === 'vendors' && profile.role === 'admin' && (
              <button 
                onClick={() => setShowAddVendor(true)}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
              >
                <Plus size={20} /> <span className="md:inline">Add Vendor</span>
              </button>
            )}
            {activeTab === 'users' && profile.role === 'admin' && (
              <button 
                onClick={() => setShowAddUser(true)}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
              >
                <Plus size={20} /> <span className="md:inline">Add Staff</span>
              </button>
            )}
          </div>
        </header>

        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
              <StatCard icon={Package} label="Total Tiles" value={tiles.reduce((acc, t) => acc + t.quantity, 0)} color="indigo" />
              <StatCard icon={AlertTriangle} label="Low Stock" value={lowStockTiles.length} color="red" pulse={lowStockTiles.length > 0} />
              <StatCard icon={TrendingUp} label="Total Transactions" value={transactions.length} color="emerald" />
              <StatCard icon={Truck} label="Total Vendors" value={vendors.length} color="purple" />
              <StatCard icon={DollarSign} label="Inventory Value" value={formatCurrency(totalValue)} color="blue" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Recent Transactions */}
              <div className="lg:col-span-2 space-y-8">
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-bold text-slate-900">Recent Transactions</h3>
                    <button onClick={() => setActiveTab('transactions')} className="text-indigo-600 text-sm font-bold hover:underline flex items-center gap-1">
                      View All <ChevronRight size={16} />
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    {/* Mobile View for Recent Transactions */}
                    <div className="md:hidden divide-y divide-slate-100">
                      {recentSales.map((t) => (
                        <div key={t.id} className="p-4 flex items-center justify-between">
                          <div>
                            <p className="font-bold text-slate-900 text-sm">{t.tileName}</p>
                            <div className="flex items-center gap-2">
                              <p className="text-[10px] text-slate-400">{safeFormatDate(t.timestamp)}</p>
                              <span className={cn(
                                "px-1 py-0.5 rounded text-[8px] font-bold uppercase",
                                t.type === 'sale' ? "bg-emerald-100 text-emerald-600" : "bg-blue-100 text-blue-600"
                              )}>
                                {t.type === 'sale' ? 'Sale' : 'Restock'}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={cn("font-bold text-sm", t.type === 'sale' ? "text-emerald-600" : "text-blue-600")}>
                              {t.type === 'sale' ? '+' : '-'}{formatCurrency(t.priceSold)}
                            </p>
                            <p className="text-[10px] text-slate-500">Qty: {t.quantity}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    {/* Desktop Table View */}
                    <table className="hidden md:table w-full text-left">
                      <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                        <tr>
                          <th className="px-6 py-4 font-semibold">Type</th>
                          <th className="px-6 py-4 font-semibold">Tile</th>
                          <th className="px-6 py-4 font-semibold">Qty</th>
                          <th className="px-6 py-4 font-semibold">Amount</th>
                          <th className="px-6 py-4 font-semibold">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {recentSales.map((t) => (
                          <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4">
                              <span className={cn(
                                "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                                t.type === 'sale' ? "bg-emerald-100 text-emerald-600" : "bg-blue-100 text-blue-600"
                              )}>
                                {t.type === 'sale' ? 'Sale' : 'Restock'}
                              </span>
                            </td>
                            <td className="px-6 py-4 font-medium text-slate-900">{t.tileName}</td>
                            <td className="px-6 py-4 text-slate-600">{t.quantity}</td>
                            <td className="px-6 py-4">
                              <div className={cn("font-bold", t.type === 'sale' ? "text-emerald-600" : "text-blue-600")}>
                                {t.type === 'sale' ? '+' : '-'}{formatCurrency(t.priceSold)}
                              </div>
                            </td>
                            <td className="px-6 py-4 text-slate-500 text-sm">
                              {safeFormatDate(t.timestamp)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {recentSales.length === 0 && (
                      <div className="px-6 py-12 text-center text-slate-400">No transactions recorded yet</div>
                    )}
                  </div>
                </div>

                {/* Recent Vendor Supplies */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                  <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-bold text-slate-900">Recent Vendor Supplies</h3>
                    <button onClick={() => setActiveTab('vendors')} className="text-indigo-600 text-sm font-bold hover:underline flex items-center gap-1">
                      View All <ChevronRight size={16} />
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                        <tr>
                          <th className="px-6 py-4 font-semibold">Vendor</th>
                          <th className="px-6 py-4 font-semibold">Product</th>
                          <th className="px-6 py-4 font-semibold">Qty</th>
                          <th className="px-6 py-4 font-semibold">Amount</th>
                          <th className="px-6 py-4 font-semibold">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {vendorTransactions.slice(0, 5).map((t) => (
                          <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                            <td className="px-6 py-4 font-medium text-slate-900">{t.vendorName}</td>
                            <td className="px-6 py-4 text-slate-600">{t.productType}</td>
                            <td className="px-6 py-4 text-slate-600">{t.quantityCartons}</td>
                            <td className="px-6 py-4 text-emerald-600 font-bold">{formatCurrency(t.amount)}</td>
                            <td className="px-6 py-4 text-slate-500 text-sm">{safeFormatDate(t.date)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {vendorTransactions.length === 0 && (
                      <div className="px-6 py-12 text-center text-slate-400">No vendor supplies recorded yet</div>
                    )}
                  </div>
                </div>
              </div>

              {/* Low Stock Alerts */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
                <div className="p-6 border-b border-slate-100">
                  <h3 className="font-bold text-slate-900">Low Stock Alerts</h3>
                </div>
                <div className="p-4 space-y-3 flex-1 overflow-y-auto max-h-[400px]">
                  {lowStockTiles.map(tile => (
                    <motion.div 
                      key={tile.id}
                      animate={{ scale: [1, 1.02, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="p-4 rounded-xl bg-red-50 border border-red-100 flex items-center gap-4"
                    >
                      <div className="w-10 h-10 bg-red-100 text-red-600 rounded-lg flex items-center justify-center flex-shrink-0">
                        <AlertTriangle size={20} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-slate-900 truncate">{tile.name}</p>
                        <p className="text-xs text-red-600 font-medium">Only {tile.quantity} left in stock</p>
                      </div>
                      <button 
                        onClick={() => { setEditingTile(tile); setActiveTab('inventory'); }}
                        className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"
                      >
                        <Edit2 size={16} />
                      </button>
                    </motion.div>
                  ))}
                  {lowStockTiles.length === 0 && (
                    <div className="h-full flex flex-col items-center justify-center text-center p-8">
                      <div className="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mb-4">
                        <CheckCircle2 size={32} />
                      </div>
                      <p className="text-slate-500 font-medium">All stock levels are healthy</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'inventory' && (
          <div className="space-y-4">
            {/* Mobile Card View */}
            <div className="grid grid-cols-1 gap-4 md:hidden">
              {filteredTiles.map((tile) => {
                const isLow = tile.quantity <= (tile.lowStockThreshold || 10);
                const isOut = tile.quantity === 0;
                return (
                  <motion.div 
                    layout
                    key={tile.id} 
                    className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-bold text-slate-900 text-lg">{tile.name}</h3>
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded text-[10px] font-bold uppercase tracking-wider">
                          {tile.type}
                        </span>
                      </div>
                      <span className={cn(
                        "px-3 py-1 rounded-full text-xs font-bold",
                        isOut ? "bg-slate-100 text-slate-500" : 
                        isLow ? "bg-red-100 text-red-600" : 
                        "bg-emerald-100 text-emerald-600"
                      )}>
                        {tile.quantity} in stock
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-5">
                      <div className="bg-slate-50 p-3 rounded-xl">
                        <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Cost Price</p>
                        <p className="text-slate-700 font-bold">{formatCurrency(tile.costPrice)}</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-xl">
                        <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Selling Price</p>
                        <p className="text-indigo-600 font-bold">{formatCurrency(tile.sellingPrice)}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => setShowSaleModal(tile)}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-emerald-600 text-white rounded-xl font-bold text-sm shadow-md shadow-emerald-100"
                      >
                        <ShoppingCart size={16} /> Sell
                      </button>
                      <button 
                        onClick={() => setShowRestockModal(tile)}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-blue-600 text-white rounded-xl font-bold text-sm shadow-md shadow-blue-100"
                      >
                        <Plus size={16} /> Restock
                      </button>
                      {profile.role === 'admin' && (
                        <>
                          <button 
                            onClick={() => setEditingTile(tile)}
                            className="p-2.5 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button 
                            onClick={() => handleDeleteTile(tile.id)}
                            className="p-2.5 bg-red-50 text-red-600 rounded-xl hover:bg-red-100"
                          >
                            <Trash2 size={18} />
                          </button>
                        </>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="Search tiles by name or type..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                    <tr>
                      <th className="px-6 py-4 font-semibold">Tile Name</th>
                      <th className="px-6 py-4 font-semibold">Type</th>
                      <th className="px-6 py-4 font-semibold">Stock</th>
                      <th className="px-6 py-4 font-semibold">Price</th>
                      <th className="px-6 py-4 font-semibold">Status</th>
                      <th className="px-6 py-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredTiles.map((tile) => {
                      const isLow = tile.quantity <= (tile.lowStockThreshold || 10);
                      const isOut = tile.quantity === 0;
                      return (
                        <tr key={tile.id} className="hover:bg-slate-50 transition-colors group">
                          <td className="px-6 py-4">
                            <div className="font-bold text-slate-900">{tile.name}</div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold uppercase tracking-wider">
                              {tile.type}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className={cn("font-mono font-bold", isLow ? "text-red-600" : "text-slate-700")}>
                              {tile.quantity}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-slate-900 font-semibold">{formatCurrency(tile.sellingPrice)}</div>
                            <div className="text-xs text-slate-400">Cost: {formatCurrency(tile.costPrice)}</div>
                          </td>
                          <td className="px-6 py-4">
                            <span className={cn(
                              "px-3 py-1 rounded-full text-xs font-bold",
                              isOut ? "bg-slate-100 text-slate-500" : 
                              isLow ? "bg-red-100 text-red-600 animate-pulse" : 
                              "bg-emerald-100 text-emerald-600"
                            )}>
                              {isOut ? 'Out of Stock' : isLow ? 'Low Stock' : 'In Stock'}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button 
                                onClick={() => setShowSaleModal(tile)}
                                className="p-2 bg-emerald-50 text-emerald-600 rounded-lg hover:bg-emerald-100 transition-colors"
                                title="Log Sale"
                              >
                                <ShoppingCart size={18} />
                              </button>
                              <button 
                                onClick={() => setShowRestockModal(tile)}
                                className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
                                title="Restock / Purchase"
                              >
                                <Plus size={18} />
                              </button>
                              {profile.role === 'admin' && (
                                <>
                                  <button 
                                    onClick={() => setEditingTile(tile)}
                                    className="p-2 bg-indigo-50 text-indigo-600 rounded-lg hover:bg-indigo-100 transition-colors"
                                    title="Edit"
                                  >
                                    <Edit2 size={18} />
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteTile(tile.id)}
                                    className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
                                    title="Delete"
                                  >
                                    <Trash2 size={18} />
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div className="space-y-4">
            {/* Mobile Card View */}
            <div className="grid grid-cols-1 gap-4 md:hidden">
              {transactions.map((t) => (
                <div key={t.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-bold text-slate-900">{t.tileName}</h3>
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-mono text-slate-400">#{t.id.slice(0, 8)}</p>
                        <span className={cn(
                          "px-1.5 py-0.5 rounded text-[8px] font-bold uppercase",
                          t.type === 'sale' ? "bg-emerald-100 text-emerald-600" : "bg-blue-100 text-blue-600"
                        )}>
                          {t.type === 'sale' ? 'Sale' : 'Restock'}
                        </span>
                      </div>
                    </div>
                    <div className={cn("font-bold", t.type === 'sale' ? "text-emerald-600" : "text-blue-600")}>
                      {t.type === 'sale' ? '+' : '-'}{formatCurrency(t.priceSold)}
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600">
                        {t.staffName?.charAt(0)}
                      </div>
                      <span className="text-slate-600">{t.staffName}</span>
                    </div>
                    <div className="text-slate-500">
                      Qty: <span className="font-bold text-slate-900">{t.quantity}</span>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-slate-50 text-[10px] text-slate-400 text-right">
                    {safeFormatDate(t.timestamp)}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-4 font-semibold">Type</th>
                    <th className="px-6 py-4 font-semibold">Tile</th>
                    <th className="px-6 py-4 font-semibold">Quantity</th>
                    <th className="px-6 py-4 font-semibold">Amount</th>
                    <th className="px-6 py-4 font-semibold">Staff</th>
                    <th className="px-6 py-4 font-semibold">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactions.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <span className={cn(
                          "px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider",
                          t.type === 'sale' ? "bg-emerald-100 text-emerald-600" : "bg-blue-100 text-blue-600"
                        )}>
                          {t.type === 'sale' ? 'Sale' : 'Restock'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-bold text-slate-900">{t.tileName}</div>
                        <div className="text-[10px] font-mono text-slate-400">#{t.id.slice(0, 8)}</div>
                      </td>
                      <td className="px-6 py-4 text-slate-600">{t.quantity}</td>
                      <td className="px-6 py-4">
                        <div className={cn("font-bold", t.type === 'sale' ? "text-emerald-600" : "text-blue-600")}>
                          {t.type === 'sale' ? '+' : '-'}{formatCurrency(t.priceSold)}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600">
                            {t.staffName?.charAt(0)}
                          </div>
                          <span className="text-sm text-slate-600">{t.staffName}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-500 text-sm">
                        {safeFormatDate(t.timestamp)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'purchases' && (
          <div className="space-y-6">
            {/* Purchase Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <p className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Total Purchase Count</p>
                <p className="text-3xl font-black text-slate-900">{transactions.filter(t => t.type === 'purchase').length}</p>
              </div>
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <p className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Total Investment</p>
                <p className="text-3xl font-black text-blue-600">
                  {formatCurrency(transactions.filter(t => t.type === 'purchase').reduce((acc, t) => acc + t.priceSold, 0))}
                </p>
              </div>
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <p className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Recent Purchase</p>
                <p className="text-lg font-bold text-slate-900 truncate">
                  {transactions.find(t => t.type === 'purchase')?.tileName || 'N/A'}
                </p>
                <p className="text-xs text-slate-400">
                  {transactions.find(t => t.type === 'purchase') ? safeFormatDate(transactions.find(t => t.type === 'purchase')!.timestamp, 'dd/MM/yyyy') : ''}
                </p>
              </div>
            </div>

            {/* Mobile Card View */}
            <div className="grid grid-cols-1 gap-4 md:hidden">
              {transactions.filter(t => t.type === 'purchase').map((t) => (
                <div key={t.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="font-bold text-slate-900">{t.tileName}</h3>
                      <p className="text-xs font-mono text-slate-400">#{t.id.slice(0, 8)}</p>
                    </div>
                    <div className="text-blue-600 font-bold">
                      -{formatCurrency(t.priceSold)}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-3">
                    <div className="bg-slate-50 p-2 rounded-lg">
                      <p className="text-[10px] text-slate-400 uppercase font-bold">Quantity</p>
                      <p className="text-sm font-bold text-slate-900">{t.quantity}</p>
                    </div>
                    <div className="bg-slate-50 p-2 rounded-lg">
                      <p className="text-[10px] text-slate-400 uppercase font-bold">Unit Cost</p>
                      <p className="text-sm font-bold text-slate-900">{formatCurrency(t.priceSold / t.quantity)}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm pt-3 border-t border-slate-50">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600">
                        {t.staffName?.charAt(0)}
                      </div>
                      <span className="text-slate-600 text-xs">{t.staffName}</span>
                    </div>
                    <span className="text-[10px] text-slate-400">
                      {safeFormatDate(t.timestamp)}
                    </span>
                  </div>
                </div>
              ))}
              {transactions.filter(t => t.type === 'purchase').length === 0 && (
                <div className="py-12 text-center text-slate-400 bg-white rounded-2xl border border-dashed border-slate-200">
                  No purchase records found
                </div>
              )}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-4 font-semibold">Purchase ID</th>
                    <th className="px-6 py-4 font-semibold">Tile Name</th>
                    <th className="px-6 py-4 font-semibold">Quantity</th>
                    <th className="px-6 py-4 font-semibold">Unit Cost</th>
                    <th className="px-6 py-4 font-semibold">Total Cost</th>
                    <th className="px-6 py-4 font-semibold">Staff</th>
                    <th className="px-6 py-4 font-semibold">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactions.filter(t => t.type === 'purchase').map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-slate-400">#{t.id.slice(0, 8)}</td>
                      <td className="px-6 py-4 font-bold text-slate-900">{t.tileName}</td>
                      <td className="px-6 py-4 text-slate-600">{t.quantity}</td>
                      <td className="px-6 py-4 text-slate-600">{formatCurrency(t.priceSold / t.quantity)}</td>
                      <td className="px-6 py-4 text-blue-600 font-bold">-{formatCurrency(t.priceSold)}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-600">
                            {t.staffName?.charAt(0)}
                          </div>
                          <span className="text-sm text-slate-600">{t.staffName}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-500 text-sm">
                        {safeFormatDate(t.timestamp)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {transactions.filter(t => t.type === 'purchase').length === 0 && (
                <div className="py-20 text-center text-slate-400">No purchase records found</div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'vendors' && (
          <div className="space-y-6">
            {selectedVendor ? (
              <div className="space-y-6">
                <button 
                  onClick={() => setSelectedVendor(null)}
                  className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-bold transition-colors"
                >
                  <ChevronRight className="rotate-180" size={20} /> Back to Vendors
                </button>
                
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-black text-slate-900">{selectedVendor.name}</h2>
                    <p className="text-slate-500">{selectedVendor.contact || 'No contact info'}</p>
                    <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-sm font-bold border border-emerald-100">
                      Total Spent: {formatCurrency(vendorTransactions.filter(t => t.vendorId === selectedVendor.id).reduce((sum, t) => sum + t.amount, 0))}
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowVendorTransactionModal(selectedVendor)}
                    className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                  >
                    <Plus size={20} /> Log New Supply
                  </button>
                </div>

                <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="p-6 border-b border-slate-100">
                    <h3 className="font-black text-slate-900 uppercase tracking-wider text-sm">Supply History</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold tracking-widest">
                        <tr>
                          <th className="px-6 py-4">Product Type</th>
                          <th className="px-6 py-4">Quantity (Cartons)</th>
                          <th className="px-6 py-4">Amount</th>
                          <th className="px-6 py-4">Staff</th>
                          <th className="px-6 py-4">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {vendorTransactions
                          .filter(t => t.vendorId === selectedVendor.id)
                          .map(t => (
                            <tr key={t.id} className="hover:bg-slate-50/50 transition-colors">
                              <td className="px-6 py-4 font-bold text-slate-900">{t.productType}</td>
                              <td className="px-6 py-4 text-slate-600">{t.quantityCartons}</td>
                              <td className="px-6 py-4 font-black text-emerald-600">{formatCurrency(t.amount)}</td>
                              <td className="px-6 py-4 text-sm text-slate-500">{t.staffName}</td>
                              <td className="px-6 py-4 text-sm text-slate-400">
                                {safeFormatDate(t.date)}
                              </td>
                            </tr>
                          ))}
                        {vendorTransactions.filter(t => t.vendorId === selectedVendor.id).length === 0 && (
                          <tr>
                            <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">
                              No transaction history for this vendor
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {vendors.map(vendor => (
                  <motion.div 
                    key={vendor.id}
                    whileHover={{ y: -5 }}
                    className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 transition-all group"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600">
                        <Truck size={28} />
                      </div>
                      {profile.role === 'admin' && (
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteVendor(vendor.id);
                          }}
                          className="p-2 text-slate-300 hover:text-red-600 transition-colors"
                        >
                          <Trash2 size={18} />
                        </button>
                      )}
                    </div>
                    <h3 className="text-xl font-black text-slate-900 mb-1 group-hover:text-indigo-600 transition-colors">{vendor.name}</h3>
                    <p className="text-sm text-slate-500 mb-2">{vendor.contact || 'No contact info'}</p>
                    <div className="mb-6">
                      <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider mb-1">Total Spent</p>
                      <p className="text-lg font-black text-emerald-600">
                        {formatCurrency(vendorTransactions.filter(t => t.vendorId === vendor.id).reduce((sum, t) => sum + t.amount, 0))}
                      </p>
                    </div>
                    <button 
                      onClick={() => setSelectedVendor(vendor)}
                      className="w-full py-3 bg-slate-50 text-slate-600 font-bold rounded-2xl group-hover:bg-indigo-600 group-hover:text-white transition-all flex items-center justify-center gap-2"
                    >
                      <Eye size={18} /> View Details
                    </button>
                  </motion.div>
                ))}
                {vendors.length === 0 && (
                  <div className="col-span-full py-20 text-center bg-white rounded-3xl border-2 border-dashed border-slate-200">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Truck size={32} className="text-slate-300" />
                    </div>
                    <p className="text-slate-400 font-bold">No vendors found. Add your first vendor to get started.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {activeTab === 'users' && profile.role === 'admin' && (
          <div className="space-y-4">
            {/* Mobile Card View */}
            <div className="grid grid-cols-1 gap-4 md:hidden">
              {allUsers.map((u) => (
                <div key={u.uid} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-lg">
                      {u.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-slate-900 truncate">{u.name}</h3>
                      <p className="text-xs text-slate-500 truncate">{u.email}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider",
                        u.role === 'admin' ? "bg-purple-100 text-purple-600" : "bg-blue-100 text-blue-600"
                      )}>
                        {u.role}
                      </span>
                      <span className={cn(
                        "px-2 py-0.5 rounded-full text-[10px] font-bold",
                        u.status === 'approved' ? "bg-emerald-100 text-emerald-600" : "bg-amber-100 text-amber-600"
                      )}>
                        {u.status}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-50">
                    {u.status === 'pending' && (
                      <button 
                        onClick={() => handleApproveUser(u.uid)}
                        className="flex-1 py-2 bg-emerald-600 text-white text-sm font-bold rounded-xl hover:bg-emerald-700 transition-all"
                      >
                        Approve Staff
                      </button>
                    )}
                    {u.uid !== user?.uid && (
                      <button 
                        onClick={() => handleDeleteUser(u.uid)}
                        className="p-2 text-slate-400 hover:text-red-600 transition-colors"
                      >
                        <Trash2 size={20} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table View */}
            <div className="hidden md:block bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-4 font-semibold">User</th>
                    <th className="px-6 py-4 font-semibold">Email</th>
                    <th className="px-6 py-4 font-semibold">Role</th>
                    <th className="px-6 py-4 font-semibold">Status</th>
                    <th className="px-6 py-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {allUsers.map((u) => (
                    <tr key={u.uid} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
                            {u.name.charAt(0)}
                          </div>
                          <div className="font-bold text-slate-900">{u.name}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-600">{u.email}</td>
                      <td className="px-6 py-4">
                        <span className={cn(
                          "px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider",
                          u.role === 'admin' ? "bg-purple-100 text-purple-600" : "bg-blue-100 text-blue-600"
                        )}>
                          {u.role}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-xs font-bold",
                          u.status === 'approved' ? "bg-emerald-100 text-emerald-600" : "bg-amber-100 text-amber-600"
                        )}>
                          {u.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        {u.status === 'pending' && (
                          <button 
                            onClick={() => handleApproveUser(u.uid)}
                            className="px-4 py-2 bg-emerald-600 text-white text-sm font-bold rounded-lg hover:bg-emerald-700 transition-all"
                          >
                            Approve
                          </button>
                        )}
                        {u.uid !== user?.uid && (
                          <button 
                            onClick={() => handleDeleteUser(u.uid)}
                            className="ml-2 p-2 text-slate-400 hover:text-red-600 transition-colors"
                          >
                            <Trash2 size={18} />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Notifications */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={cn(
              "fixed bottom-8 right-8 px-6 py-3 rounded-xl shadow-2xl z-[200] flex items-center gap-3 font-bold",
              notification.type === 'success' ? "bg-emerald-600 text-white" : "bg-red-600 text-white"
            )}
          >
            {notification.type === 'success' ? <CheckCircle2 size={20} /> : <XCircle size={20} />}
            {notification.message}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modals */}
      <AnimatePresence>
        {showTileSelector && (
          <TileSelectorModal 
            tiles={tiles}
            mode={showTileSelector.mode}
            onClose={() => setShowTileSelector(null)}
            onSelect={(tile) => {
              if (showTileSelector.mode === 'sale') setShowSaleModal(tile);
              else setShowRestockModal(tile);
              setShowTileSelector(null);
            }}
          />
        )}
        {(showAddTile || editingTile) && (
          <TileModal 
            tile={editingTile} 
            onClose={() => { setShowAddTile(false); setEditingTile(null); }} 
            onSuccess={(msg) => setNotification({ message: msg, type: 'success' })}
          />
        )}
        {showAddUser && (
          <UserModal 
            onClose={() => setShowAddUser(false)} 
            onSuccess={(msg) => setNotification({ message: msg, type: 'success' })}
          />
        )}
        {showSaleModal && (
          <SaleModal 
            tile={showSaleModal} 
            onClose={() => setShowSaleModal(null)} 
            staffProfile={profile}
            onSuccess={(msg) => setNotification({ message: msg, type: 'success' })}
          />
        )}
        {showRestockModal && (
          <RestockModal 
            tile={showRestockModal} 
            onClose={() => setShowRestockModal(null)} 
            staffProfile={profile}
            onSuccess={(msg) => setNotification({ message: msg, type: 'success' })}
          />
        )}
        {showAddVendor && (
          <VendorModal 
            onClose={() => setShowAddVendor(false)}
            onSuccess={(msg) => setNotification({ message: msg, type: 'success' })}
          />
        )}
        {showVendorTransactionModal && (
          <VendorTransactionModal 
            vendor={showVendorTransactionModal}
            onClose={() => setShowVendorTransactionModal(null)}
            staffProfile={profile}
            onSuccess={(msg) => setNotification({ message: msg, type: 'success' })}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

const TileSelectorModal = ({ tiles, mode, onClose, onSelect }: { tiles: Tile[], mode: 'sale' | 'restock', onClose: () => void, onSelect: (tile: Tile) => void }) => {
  const [search, setSearch] = useState('');
  const filtered = tiles.filter(t => 
    t.name.toLowerCase().includes(search.toLowerCase()) || 
    t.type.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[80vh]"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-xl font-black text-slate-900">Select Tile for {mode === 'sale' ? 'Sale' : 'Restock'}</h3>
            <p className="text-sm text-slate-500">Choose a tile from inventory to continue</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors bg-white rounded-full shadow-sm">
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6 border-b border-slate-100">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              autoFocus
              type="text" 
              placeholder="Search by name or type..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-3.5 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 outline-none transition-all text-lg font-medium"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filtered.map(tile => (
            <button
              key={tile.id}
              onClick={() => onSelect(tile)}
              className="w-full flex items-center justify-between p-4 rounded-2xl hover:bg-slate-50 transition-all group text-left border border-transparent hover:border-slate-200"
            >
              <div className="flex-1 min-w-0">
                <p className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors truncate">{tile.name}</p>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">{tile.type}</p>
              </div>
              <div className="text-right ml-4">
                <p className={cn(
                  "text-sm font-black",
                  tile.quantity <= (tile.lowStockThreshold || 10) ? "text-red-600" : "text-slate-700"
                )}>
                  {tile.quantity} <span className="text-[10px] uppercase text-slate-400">in stock</span>
                </p>
                <p className="text-xs font-bold text-indigo-600">{formatCurrency(tile.sellingPrice)}</p>
              </div>
            </button>
          ))}
          {filtered.length === 0 && (
            <div className="py-20 text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search size={32} className="text-slate-300" />
              </div>
              <p className="text-slate-400 font-medium">No tiles found matching your search</p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

const StatCard = ({ icon: Icon, label, value, color, pulse }: any) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className={cn(
      "bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-3 md:gap-5",
      pulse && "ring-2 ring-red-500 ring-offset-2"
    )}
  >
    <div className={cn(
      "w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg",
      color === 'indigo' ? "bg-indigo-600 text-white shadow-indigo-100" :
      color === 'red' || color === 'rose' ? "bg-red-600 text-white shadow-red-100" :
      color === 'emerald' ? "bg-emerald-600 text-white shadow-emerald-100" :
      color === 'purple' ? "bg-purple-600 text-white shadow-purple-100" :
      "bg-blue-600 text-white shadow-blue-100"
    )}>
      <Icon size={20} className="md:w-7 md:h-7" />
    </div>
    <div>
      <p className="text-slate-500 text-[10px] md:text-sm font-medium uppercase tracking-wider md:normal-case">{label}</p>
      <p className="text-lg md:text-2xl font-bold text-slate-900">{value}</p>
    </div>
  </motion.div>
);

const UserModal = ({ onClose, onSuccess }: { onClose: () => void, onSuccess: (msg: string) => void }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: 'staff' as 'admin' | 'staff',
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      // Create a document in the users collection with the email as the ID
      const userEmail = formData.email.toLowerCase().trim();
      const userRef = doc(db, 'users', userEmail);
      await setDoc(userRef, {
        uid: userRef.id, // Placeholder ID (the email)
        name: formData.name,
        email: userEmail,
        role: formData.role,
        status: 'approved',
        createdAt: new Date().toISOString()
      });
      onSuccess(`Staff ${formData.name} approved! They can now login with Google.`);
      onClose();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xl font-bold text-slate-900">Approve New Staff Email</h3>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg border border-red-100">{error}</div>
          )}

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Full Name</label>
            <input 
              required
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="John Doe"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Email Address</label>
            <input 
              type="email"
              required
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="staff@company.com"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Role</label>
            <select 
              value={formData.role}
              onChange={e => setFormData({...formData, role: e.target.value as any})}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            >
              <option value="staff">Staff</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <div className="pt-4 flex gap-3">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-all"
            >
              Cancel
            </button>
            <button 
              type="submit"
              disabled={loading}
              className="flex-1 py-3 px-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-70"
            >
              {loading ? 'Approving...' : 'Approve Email'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

const TileModal = ({ tile, onClose, onSuccess }: { tile: Tile | null, onClose: () => void, onSuccess: (msg: string) => void }) => {
  const [formData, setFormData] = useState({
    name: tile?.name || '',
    type: tile?.type || 'Ceramic',
    quantity: tile?.quantity || 0,
    costPrice: tile?.costPrice || 0,
    sellingPrice: tile?.sellingPrice || 0,
    lowStockThreshold: tile?.lowStockThreshold || 10,
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = { ...formData, updatedAt: new Date().toISOString() };
      if (tile) {
        await updateDoc(doc(db, 'tiles', tile.id), data);
        onSuccess('Tile updated successfully!');
      } else {
        await addDoc(collection(db, 'tiles'), data);
        onSuccess('New tile added to inventory!');
      }
      onClose();
    } catch (err) {
      handleFirestoreError(err, tile ? OperationType.UPDATE : OperationType.CREATE, 'tiles');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xl font-bold text-slate-900">{tile ? 'Edit Tile' : 'Add New Tile'}</h3>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-bold text-slate-700 mb-1">Tile Name</label>
              <input 
                required
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="e.g. Polished Marble Tile"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Type</label>
              <select 
                value={formData.type}
                onChange={e => setFormData({...formData, type: e.target.value})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
              >
                <option>Ceramic</option>
                <option>Porcelain</option>
                <option>Marble</option>
                <option>Granite</option>
                <option>Glass</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Initial Stock</label>
              <input 
                type="number"
                required
                value={isNaN(formData.quantity) ? '' : formData.quantity}
                onChange={e => setFormData({...formData, quantity: e.target.value === '' ? 0 : parseInt(e.target.value) || 0})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Cost Price</label>
              <input 
                type="number"
                step="0.01"
                required
                value={isNaN(formData.costPrice) ? '' : formData.costPrice}
                onChange={e => setFormData({...formData, costPrice: e.target.value === '' ? 0 : parseFloat(e.target.value) || 0})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Selling Price</label>
              <input 
                type="number"
                step="0.01"
                required
                value={isNaN(formData.sellingPrice) ? '' : formData.sellingPrice}
                onChange={e => setFormData({...formData, sellingPrice: e.target.value === '' ? 0 : parseFloat(e.target.value) || 0})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-bold text-slate-700 mb-1">Low Stock Threshold</label>
              <input 
                type="number"
                required
                value={isNaN(formData.lowStockThreshold) ? '' : formData.lowStockThreshold}
                onChange={e => setFormData({...formData, lowStockThreshold: e.target.value === '' ? 0 : parseInt(e.target.value) || 0})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          <div className="pt-4 flex gap-3">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 bg-slate-100 text-slate-700 font-bold rounded-xl hover:bg-slate-200 transition-all"
            >
              Cancel
            </button>
            <button 
              type="submit"
              disabled={loading}
              className="flex-1 py-3 px-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-70"
            >
              {loading ? 'Saving...' : tile ? 'Update Tile' : 'Add Tile'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

const SaleModal = ({ tile, onClose, staffProfile, onSuccess }: { tile: Tile, onClose: () => void, staffProfile: UserProfile, onSuccess: (msg: string) => void }) => {
  const [qty, setQty] = useState(1);
  const [price, setPrice] = useState(tile.sellingPrice);
  const [loading, setLoading] = useState(false);

  const handleSale = async (e: React.FormEvent) => {
    e.preventDefault();
    if (qty > tile.quantity) {
      alert("Not enough stock!");
      return;
    }
    setLoading(true);
    try {
      const batch = writeBatch(db);
      
      // Add transaction
      const transRef = doc(collection(db, 'transactions'));
      batch.set(transRef, {
        tileId: tile.id,
        tileName: tile.name,
        quantity: qty,
        priceSold: price * qty,
        type: 'sale',
        staffId: staffProfile.uid,
        staffName: staffProfile.name,
        timestamp: new Date().toISOString()
      });

      // Update tile stock
      const tileRef = doc(db, 'tiles', tile.id);
      batch.update(tileRef, {
        quantity: tile.quantity - qty,
        updatedAt: new Date().toISOString()
      });

      await batch.commit();
      onSuccess(`Sale of ${qty} ${tile.name} logged!`);
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'sale');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xl font-bold text-slate-900">Log Sale</h3>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleSale} className="p-6 space-y-6">
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Tile Selected</p>
            <p className="text-lg font-bold text-slate-900">{tile.name}</p>
            <p className="text-sm text-slate-600">Available Stock: <span className="font-bold">{tile.quantity}</span></p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Quantity Sold</label>
              <input 
                type="number"
                min="1"
                max={tile.quantity}
                required
                value={isNaN(qty) ? '' : qty}
                onChange={e => setQty(e.target.value === '' ? 0 : parseInt(e.target.value) || 0)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Selling Price (Unit)</label>
              <input 
                type="number"
                step="0.01"
                required
                value={isNaN(price) ? '' : price}
                onChange={e => setPrice(e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center justify-between">
            <span className="font-bold text-emerald-800">Total Sale Amount</span>
            <span className="text-xl font-black text-emerald-600">{formatCurrency(price * qty)}</span>
          </div>

          <button 
            type="submit"
            disabled={loading || qty > tile.quantity}
            className="w-full py-4 px-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 disabled:opacity-50"
          >
            {loading ? 'Processing...' : 'Complete Sale'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const RestockModal = ({ tile, onClose, staffProfile, onSuccess }: { tile: Tile, onClose: () => void, staffProfile: UserProfile, onSuccess: (msg: string) => void }) => {
  const [qty, setQty] = useState(1);
  const [cost, setCost] = useState(tile.costPrice);
  const [loading, setLoading] = useState(false);

  const handleRestock = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const batch = writeBatch(db);
      
      // Add transaction
      const transRef = doc(collection(db, 'transactions'));
      batch.set(transRef, {
        tileId: tile.id,
        tileName: tile.name,
        quantity: qty,
        priceSold: cost * qty,
        type: 'purchase',
        staffId: staffProfile.uid,
        staffName: staffProfile.name,
        timestamp: new Date().toISOString()
      });

      // Update tile stock
      const tileRef = doc(db, 'tiles', tile.id);
      batch.update(tileRef, {
        quantity: tile.quantity + qty,
        costPrice: cost, // Update cost price to latest purchase price
        updatedAt: new Date().toISOString()
      });

      await batch.commit();
      onSuccess(`Restocked ${qty} ${tile.name} successfully!`);
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'restock');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xl font-bold text-slate-900">Restock / Purchase</h3>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </div>
        <form onSubmit={handleRestock} className="p-6 space-y-6">
          <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
            <p className="text-xs text-blue-500 uppercase font-bold tracking-wider mb-1">Tile Selected</p>
            <p className="text-lg font-bold text-slate-900">{tile.name}</p>
            <p className="text-sm text-slate-600">Current Stock: <span className="font-bold">{tile.quantity}</span></p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Quantity Added</label>
              <input 
                type="number"
                min="1"
                required
                value={isNaN(qty) ? '' : qty}
                onChange={e => setQty(e.target.value === '' ? 0 : parseInt(e.target.value) || 0)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Purchase Cost (Unit)</label>
              <input 
                type="number"
                step="0.01"
                required
                value={isNaN(cost) ? '' : cost}
                onChange={e => setCost(e.target.value === '' ? 0 : parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 flex items-center justify-between">
            <span className="font-bold text-blue-800">Total Purchase Cost</span>
            <span className="text-xl font-black text-blue-600">{formatCurrency(cost * qty)}</span>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full py-4 px-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 disabled:opacity-50"
          >
            {loading ? 'Processing...' : 'Complete Purchase'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

// Admin Actions
// Handlers moved inside Dashboard component

const VendorModal = ({ onClose, onSuccess }: { onClose: () => void, onSuccess: (msg: string) => void }) => {
  const [formData, setFormData] = useState({ name: '', contact: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addDoc(collection(db, 'vendors'), {
        ...formData,
        createdAt: serverTimestamp()
      });
      onSuccess('Vendor added successfully');
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'vendors');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h3 className="text-xl font-black text-slate-900">Add New Vendor</h3>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors bg-white rounded-full shadow-sm">
            <X size={20} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Vendor Name</label>
            <input 
              type="text" 
              required
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g. Global Tiles Ltd"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Contact Info (Optional)</label>
            <input 
              type="text" 
              value={formData.contact}
              onChange={e => setFormData({...formData, contact: e.target.value})}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Phone or Email"
            />
          </div>
          <button 
            type="submit"
            disabled={loading}
            className="w-full py-4 px-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50"
          >
            {loading ? 'Adding...' : 'Add Vendor'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};

const VendorTransactionModal = ({ vendor, onClose, staffProfile, onSuccess }: { vendor: Vendor, onClose: () => void, staffProfile: any, onSuccess: (msg: string) => void }) => {
  const [formData, setFormData] = useState({
    productType: '',
    quantityCartons: 0,
    amount: 0
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await addDoc(collection(db, 'vendorTransactions'), {
        vendorId: vendor.id,
        vendorName: vendor.name,
        ...formData,
        date: serverTimestamp(),
        staffId: staffProfile.uid,
        staffName: staffProfile.name
      });
      onSuccess('Transaction logged successfully');
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'vendorTransactions');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-xl font-black text-slate-900">Log Supply</h3>
            <p className="text-sm text-slate-500">For {vendor.name}</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors bg-white rounded-full shadow-sm">
            <X size={20} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Product Type</label>
            <input 
              type="text" 
              required
              value={formData.productType}
              onChange={e => setFormData({...formData, productType: e.target.value})}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g. 60x60 Ceramic"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Quantity (Cartons)</label>
              <input 
                type="number" 
                required
                min="1"
                value={formData.quantityCartons || ''}
                onChange={e => setFormData({...formData, quantityCartons: parseInt(e.target.value) || 0})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-1">Total Amount</label>
              <input 
                type="number" 
                required
                min="0"
                step="0.01"
                value={formData.amount || ''}
                onChange={e => setFormData({...formData, amount: parseFloat(e.target.value) || 0})}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          <button 
            type="submit"
            disabled={loading}
            className="w-full py-4 px-4 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 disabled:opacity-50"
          >
            {loading ? 'Logging...' : 'Log Transaction'}
          </button>
        </form>
      </motion.div>
    </div>
  );
};
