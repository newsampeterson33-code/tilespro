export type UserRole = 'admin' | 'staff';
export type UserStatus = 'pending' | 'approved';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  createdAt: string;
}

export interface Tile {
  id: string;
  name: string;
  type: string;
  quantity: number;
  costPrice: number;
  sellingPrice: number;
  lowStockThreshold: number;
  updatedAt: string;
}

export interface Transaction {
  id: string;
  tileId: string;
  tileName: string;
  quantity: number;
  priceSold: number;
  type: 'sale' | 'purchase';
  staffId: string;
  staffName: string;
  timestamp: string;
}

export interface Vendor {
  id: string;
  name: string;
  contact?: string;
  createdAt: string;
}

export interface VendorTransaction {
  id: string;
  vendorId: string;
  vendorName: string;
  productType: string;
  quantityCartons: number;
  amount: number;
  date: string;
  staffId: string;
  staffName: string;
}
