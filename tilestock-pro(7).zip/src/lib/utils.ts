import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format } from 'date-fns';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number) {
  return new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function safeFormatDate(date: any, formatStr: string = 'dd/MM/yyyy hh:mm a') {
  if (!date) return 'N/A';
  
  let d: Date;
  
  // Handle Firestore Timestamp
  if (date && typeof date === 'object' && 'seconds' in date && 'nanoseconds' in date) {
    d = new Date(date.seconds * 1000);
  } else if (date && typeof date.toDate === 'function') {
    d = date.toDate();
  } else if (date instanceof Date) {
    d = date;
  } else {
    d = new Date(date);
  }

  if (isNaN(d.getTime())) {
    return 'N/A';
  }

  return format(d, formatStr);
}
